/*----------------------------------------------------------
*				HTBLA-Leonding / Klasse: 2AHIF
* ---------------------------------------------------------
* Exercise Number: 5
* Title:			car.h
* Author:			Patrick Spisak
* Due Date:		November 24 2017
* ----------------------------------------------------------
* Description:
* Car abstract data type demo.
* ----------------------------------------------------------
*/
#ifndef ___CAR_H
#define ___CAR_H

enum Color {RED , GREEN , BLUE , ORANGE , SILVER , BLACK};
enum CarType {FIAT_MULTIPLA , JEEP , AIXAM};

typedef struct CarImplementation* Car;

CarType get_type(Car car1);
Color get_color(Car car1);
double get_fill_level(Car car1);
double get_acceleration_rate(Car car1);
int get_speed(Car car1);
void init();
Car get_car(CarType type );
void set_acceleration_rate(Car car1, double number);
void accelerate(Car car);



#endif
