### if.03.22 Procedural Programming
# Assignment – Abstract data type
## Car
With this assignment you will be create your first abstract data type in C. Clone this assignment, open the index.html read the assignment and try to make all unit tests green.
