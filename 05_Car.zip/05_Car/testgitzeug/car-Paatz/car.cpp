#include <stdio.h>
#include "car.h"

#define AIXAM_MAX_SPEED 45
#define FIAT_MULTIPLA_MAX_SPEED 170
#define JEEP_MAX_SPEED 196

#define AIXAM_MAX_ACCELERATION 1.0
#define AIXAM_MIN_ACCELERATION -8.0
#define FIAT_MULTIPLA_MAX_ACCELERATION 2.26
#define JEEP_MAX_ACCELERATION 3.14



struct CarImplementation
{
    CarType type;
    Color color;
    int current_speed;
    double fillLevel;
    double acceleration;
    bool isRented;
};


struct CarImplementation A1 =  {AIXAM , RED , 0 , 16.0 , 0.0 , false};
static struct CarImplementation M1 =  {FIAT_MULTIPLA , GREEN , 0 , 65.0 , 0.0 , false};
static struct CarImplementation M2 =  {FIAT_MULTIPLA , BLUE , 0 , 65.0 , 0.0 , false};
static struct CarImplementation M3 =  {FIAT_MULTIPLA , ORANGE , 0 , 65.0 , 0.0 , false};
static struct CarImplementation J1 =  {JEEP , SILVER , 0 , 80.0 , 0.0 , false};
static struct CarImplementation J2 =  {JEEP , BLACK , 0 , 80.0 , 0.0 , false};
static struct CarImplementation carArray[6]= {A1,M1,M2,M3,J1,J2};

Car get_car (CarType type)
{
  for(int i = 0; i < 6; i++)
  {
    /*if(carArray[i].isRented == true )
    {
      printf("IS RENTED == TRUE !!!!!!\n");
    }
*/
    if(type == carArray[i].type && carArray[i].isRented == false)
    {
      carArray[i].isRented = true;
      return &carArray[i];
    }
  }

  return 0;
}

CarType get_type(Car car1)
{
  return car1 -> type ;
}

Color get_color(Car car1)
{
  return car1 -> color ;
}

double get_fill_level(Car car1)
{
    return car1 -> fillLevel;
}

double get_acceleration_rate(Car car1)
{
  return car1 -> acceleration;
}

int get_speed(Car car1)
{



     return car1 -> current_speed;
}

void init()
{
  for(int i = 0 ; i < 6 ; i++)
  {
    carArray[i].isRented = false;
    carArray[i].acceleration = 0;
    carArray[i].current_speed = 0;
  }
}

void set_acceleration_rate(Car car1, double number)
{
   /*double numberDouble = (double)number + 0.5;
   number = (int)numberDouble;
*/
    if(car1 -> type == AIXAM && number > AIXAM_MAX_ACCELERATION )
    {
        number = AIXAM_MAX_ACCELERATION;
    }

    if(car1 -> type == AIXAM && number < -1*8.0 )
    {
      number = AIXAM_MIN_ACCELERATION;
    }

    else if(car1 -> type == FIAT_MULTIPLA && number > FIAT_MULTIPLA_MAX_ACCELERATION)
    {
      number = FIAT_MULTIPLA_MAX_ACCELERATION;
    }

    else if(car1 -> type == JEEP && number > JEEP_MAX_ACCELERATION)
    {
      number = JEEP_MAX_ACCELERATION;
    }

    car1 -> acceleration = number;
}

void accelerate(Car car1)
{
    car1 -> current_speed += (int)((car1 -> acceleration * 3.6)+0.5);

    if(car1 -> type == AIXAM && car1 -> current_speed > AIXAM_MAX_SPEED)
    {

         car1 -> current_speed = AIXAM_MAX_SPEED;

    }

    else if(car1 -> type == FIAT_MULTIPLA && car1 -> current_speed > FIAT_MULTIPLA_MAX_SPEED)
    {
          car1 -> current_speed = FIAT_MULTIPLA_MAX_SPEED;
    }

    else if(car1 -> type == JEEP && car1 -> current_speed > JEEP_MAX_SPEED)
    {
          car1 -> current_speed = JEEP_MAX_SPEED;
    }
}
